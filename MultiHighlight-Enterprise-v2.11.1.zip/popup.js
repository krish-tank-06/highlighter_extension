/**
 * Multi Highlight — Popup Logic
 * Enterprise Edition (Manifest V3)
 * XSS-hardened, ReDoS-protected, memory-optimized
 */
"use strict";

const defaultSettings = {
    delim: ",",
    isAlwaysSearch: false,
    isOn: true,
    isCasesensitive: false,
    isInstant: true,
    isNewlineNewColor: false,
    isSaveKws: false,
    isWholeWord: false,
    latest_keywords: [],
    element: "mh",
    CSSprefix1: "chrome-extension-FindManyStrings",
    CSSprefix2: "chrome-extension-FindManyStrings-style-",
    CSSprefix3: "CE-FMS-"
};

const defaultPopupConfig = {
    popup_height: 100,
    popup_width: 420
};

let currentTabId = null;
let currentTabKey = null;
let inputDebounceTimer = null;

function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function get_tabkey(tabId) {
    return "multi-highlight_" + tabId;
}

function get_tabId(tabkey) {
    return parseInt(tabkey.substring(16), 10);
}

function safeSendTabMessage(tabId, message, callback) {
    if (!tabId) return;
    try {
        chrome.tabs.sendMessage(tabId, message, function (response) {
            const err = chrome.runtime.lastError;
            if (callback) {
                callback(response, err);
            }
        });
    } catch (e) {
        // Silently consume errors to invalid/unloaded tabs
    }
}

window.addEventListener("load", function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const currTab = tabs && tabs[0];
        if (!currTab) return;

        currentTabId = currTab.id;
        currentTabKey = get_tabkey(currentTabId);

        chrome.storage.local.get(["settings", "popupConfig", currentTabKey], function (result) {
            const settings = Object.assign({}, defaultSettings, result.settings);
            const popupConfig = Object.assign({}, defaultPopupConfig, result.popupConfig);

            const container = document.getElementById("container");
            const highlightWords = document.getElementById("highlightWords");
            const delimiter = document.getElementById("delimiter");
            const instant = document.getElementById("instant");
            const toggleMHL = document.getElementById("toggleMHL");
            const alwaysSearch = document.getElementById("alwaysSearch");
            const newlineNewColor = document.getElementById("newlineNewColor");
            const casesensitive = document.getElementById("casesensitive");
            const wholeWord = document.getElementById("wholeWord");
            const saveWords = document.getElementById("saveWords");

            if (popupConfig.popup_width && container) {
                container.style.width = popupConfig.popup_width + "px";
            }
            if (popupConfig.popup_height && highlightWords) {
                highlightWords.style.minHeight = popupConfig.popup_height + "px";
            }

            const tabinfo = result[currentTabKey];
            if (typeof tabinfo === "undefined") {
                highlightWords.value = "";
                highlightWords.disabled = true;
                highlightWords.placeholder = "[ Extension Disabled on this page ]\n\nPlease navigate to a regular webpage or refresh.";
                updateChipCount(0);
                return;
            }

            highlightWords.disabled = false;
            highlightWords.value = keywordsToStr(tabinfo.keywords || [], settings);

            delimiter.value = settings.delim || ",";
            instant.checked = Boolean(settings.isInstant);
            toggleMHL.checked = Boolean(settings.isOn);
            alwaysSearch.checked = Boolean(settings.isAlwaysSearch);
            newlineNewColor.checked = Boolean(settings.isNewlineNewColor);
            casesensitive.checked = Boolean(settings.isCasesensitive);
            wholeWord.checked = Boolean(settings.isWholeWord);
            saveWords.checked = Boolean(settings.isSaveKws);

            build_keywords_list(tabinfo.keywords || []);

            // Synchronize state on popup open
            chrome.storage.local.set({
                [currentTabKey]: tabinfo,
                settings: settings,
                popupConfig: popupConfig
            }, function () {
                handle_highlightWords_change(currentTabKey, { refresh: true, fromBgOrPopup: true });
            });

            // Input handlers with debouncing for high-performance typing
            $("#highlightWords").on("input", function () {
                clearTimeout(inputDebounceTimer);
                inputDebounceTimer = setTimeout(function () {
                    handle_highlightWords_change(currentTabKey, { fromBgOrPopup: true });
                }, 100);
            });

            // Options toggling
            $("#toggleMHL, #casesensitive, #wholeWord, #delimiter, #instant, #saveWords, #alwaysSearch, #newlineNewColor").on("change input", function (event) {
                handle_option_change(currentTabKey, event);
            });

            // Action buttons
            $("#forceRefresh").on("click", function () {
                handle_highlightWords_change(currentTabKey, { refresh: true, fromBgOrPopup: true });
            });

            $("#clearAllWordsBtn").on("click", function () {
                highlightWords.value = "";
                handle_highlightWords_change(currentTabKey, { refresh: true, fromBgOrPopup: true });
            });

            $("#options_icon").on("click", function () {
                if (chrome.runtime.openOptionsPage) {
                    chrome.runtime.openOptionsPage();
                }
            });

            // Keep connection port open
            try {
                chrome.runtime.connect({ name: "popup_" + currentTabId });
            } catch (e) {}
        });

        check_keywords_existence(currentTabId);
    });
});

/**
 * XSS-Safe Keyword Chips Builder with visual color parity
 */
function build_keywords_list(inputKws) {
    const listContainer = document.getElementById("kw-list");
    if (!listContainer) return;

    listContainer.innerHTML = "";
    updateChipCount(inputKws.length);

    inputKws.forEach((kw) => {
        if (!kw || !kw.kwStr) return;

        const chip = document.createElement("span");
        const colorGrp = (kw.kwGrp !== undefined ? kw.kwGrp : 0) % 20;
        chip.className = `kw-chip chrome-extension-FindManyStrings-style-${colorGrp}`;
        chip.title = "Click to remove keyword";

        const textSpan = document.createElement("span");
        textSpan.textContent = kw.kwStr;

        const closeSpan = document.createElement("span");
        closeSpan.className = "close-btn";
        closeSpan.innerHTML = "&times;";

        chip.appendChild(textSpan);
        chip.appendChild(closeSpan);

        chip.addEventListener("click", function () {
            removeKeyword(kw.kwStr);
        });

        listContainer.appendChild(chip);
    });

    if (currentTabId) {
        check_keywords_existence(currentTabId);
    }
}

function updateChipCount(count) {
    const badge = document.getElementById("kwCountBadge");
    if (badge) {
        badge.textContent = `${count} keyword${count !== 1 ? "s" : ""}`;
    }
}

function removeKeyword(kwToRemove) {
    chrome.storage.local.get(["settings", currentTabKey], function (result) {
        const settings = result.settings || defaultSettings;
        const highlightWords = document.getElementById("highlightWords");
        const currentKws = keywordsFromStr(highlightWords.value, settings);

        const filteredKws = currentKws.filter(k => k.kwStr !== kwToRemove);
        highlightWords.value = keywordsToStr(filteredKws, settings);

        handle_highlightWords_change(currentTabKey, { fromBgOrPopup: true });
    });
}

/**
 * Checks keyword availability safely without regex crashes
 */
function check_keywords_existence(tabId) {
    if (!tabId) return;

    chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["getPagesSource.js"]
    }, function () {
        if (chrome.runtime.lastError) {
            console.warn("Script injection skipped:", chrome.runtime.lastError.message);
            const highlightWords = document.getElementById("highlightWords");
            if (highlightWords && highlightWords.disabled) {
                highlightWords.placeholder = "[ Extension unavailable on this page ]";
            }
        }
    });
}

chrome.runtime.onMessage.addListener(function (request) {
    if (request && request.action === "getVisibleText") {
        const visibleText = request.source || "";
        chrome.storage.local.get(["settings"], function (result) {
            const settings = result.settings || defaultSettings;
            const chips = document.querySelectorAll("#kw-list .kw-chip");

            chips.forEach(chip => {
                const textElem = chip.querySelector("span");
                const kwText = textElem ? textElem.textContent : "";
                if (!kwText) return;

                const safeKw = escapeRegExp(kwText);
                const pattern = settings.isWholeWord ? `\\b(${safeKw})\\b` : `(${safeKw})`;
                const flags = settings.isCasesensitive ? "" : "i";

                try {
                    const regex = new RegExp(pattern, flags);
                    if (regex.test(visibleText)) {
                        chip.classList.remove("notAvailable");
                    } else {
                        chip.classList.add("notAvailable");
                    }
                } catch (e) {
                    chip.classList.remove("notAvailable");
                }
            });
        });
    }
});

function handle_highlightWords_change(tabkey, option = {}, callback = null) {
    chrome.storage.local.get(["settings", tabkey], function (result) {
        if (!result || !result.settings) return;

        const settings = result.settings;
        const tabinfo = result[tabkey] || { keywords: [] };
        const tabId = get_tabId(tabkey);
        const highlightWords = document.getElementById("highlightWords");

        if (!settings.isOn) {
            safeSendTabMessage(tabId, { action: "hl_clearall" });
            return;
        }

        let inputStr = option.useSavedKws
            ? keywordsToStr(tabinfo.keywords, settings)
            : (highlightWords ? highlightWords.value : "");

        if (settings.isInstant || inputStr.slice(-1) === settings.delim) {
            const inputKws = keywordsFromStr(inputStr, settings);
            const savedKws = tabinfo.keywords || [];

            const addedKws = KeywordsMinus(inputKws, savedKws);
            const removedKws = KeywordsMinus(savedKws, inputKws);

            if (option.refresh) {
                safeSendTabMessage(tabId, {
                    action: "hl_refresh",
                    inputKws: [...inputKws]
                });
            } else {
                safeSendTabMessage(tabId, {
                    action: "_hl_clear",
                    removedKws: removedKws
                }, function (response, err) {
                    if (err) return;
                    safeSendTabMessage(tabId, {
                        action: "_hl_search",
                        addedKws: addedKws
                    });
                });
            }

            tabinfo.keywords = inputKws;

            if (option.fromBgOrPopup) {
                build_keywords_list(inputKws);
            }

            settings.latest_keywords = inputKws;
            chrome.storage.local.set({ [tabkey]: tabinfo, settings: settings });
        } else if (!inputStr.trim()) {
            safeSendTabMessage(tabId, { action: "hl_clearall" });
            tabinfo.keywords = [];
            settings.latest_keywords = [];
            build_keywords_list([]);
            chrome.storage.local.set({ [tabkey]: tabinfo, settings: settings });
        }

        if (typeof callback === "function") callback();
    });
}

function handle_option_change(tabkey, event) {
    const forceRefresh = event && (
        event.target.id === "newlineNewColor" ||
        event.target.id === "wholeWord" ||
        event.target.id === "casesensitive" ||
        event.target.id === "delimiter" ||
        event.target.id === "toggleMHL"
    );

    chrome.storage.local.get(["settings"], function (result) {
        const settings = result.settings || defaultSettings;
        const toggleMHL = document.getElementById("toggleMHL");
        const delimiter = document.getElementById("delimiter");
        const instant = document.getElementById("instant");
        const alwaysSearch = document.getElementById("alwaysSearch");
        const newlineNewColor = document.getElementById("newlineNewColor");
        const casesensitive = document.getElementById("casesensitive");
        const wholeWord = document.getElementById("wholeWord");
        const saveWords = document.getElementById("saveWords");

        settings.isOn = toggleMHL.checked;
        settings.delim = delimiter.value || ",";
        settings.isInstant = instant.checked;
        settings.isAlwaysSearch = alwaysSearch.checked;
        settings.isNewlineNewColor = newlineNewColor.checked;
        settings.isCasesensitive = casesensitive.checked;
        settings.isWholeWord = wholeWord.checked;
        settings.isSaveKws = saveWords.checked;

        chrome.storage.local.set({ settings: settings }, function () {
            if (tabkey) {
                handle_highlightWords_change(tabkey, { refresh: forceRefresh, fromBgOrPopup: true });
            }
        });
    });
}

function keywordsFromStr(inputStr, settings) {
    if (!inputStr) return [];
    const delim = settings.delim || ",";

    if (settings.isNewlineNewColor) {
        return inputStr.split(/\n/g).filter(Boolean).reduce((arr, line, lineCnt) => {
            return arr.concat(line.split(delim).map(s => s.trim()).filter(Boolean).map(kws => {
                return { kwGrp: (lineCnt % 20), kwStr: kws };
            }));
        }, []);
    } else {
        return inputStr.split(delim).map(s => s.trim()).filter(Boolean).map((kws, cnt) => {
            return { kwGrp: (cnt % 20), kwStr: kws };
        });
    }
}

function keywordsToStr(kws, settings) {
    if (!kws || kws.length === 0) return "";
    const delim = settings.delim || ",";

    if (settings.isNewlineNewColor) {
        let str = "";
        for (let i = 0, len = kws.length - 1; i < len; ++i) {
            str += kws[i].kwStr + ((kws[i].kwGrp !== kws[i + 1].kwGrp) ? "\n" : (delim + " "));
        }
        if (kws.length > 0) {
            str += kws[kws.length - 1].kwStr;
        }
        return str;
    } else {
        return kws.map(kw => kw.kwStr).join(delim + " ");
    }
}

function KeywordsMinus(kwListA, kwListB) {
    function KwListContain(kwList, kwA) {
        for (const kw of kwList) {
            if (kw.kwStr === kwA.kwStr && kw.kwGrp === kwA.kwGrp) {
                return true;
            }
        }
        return false;
    }
    return kwListA.filter(x => !KwListContain(kwListB, x));
}