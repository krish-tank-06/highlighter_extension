/**
 * Multi Highlight — Content Script
 * Enterprise Edition (Manifest V3)
 * High-performance, memory-safe DOM keyword highlighter
 */
(function () {
    "use strict";

    let tabId = null;
    let tabkey = null;
    let observer = null;
    let mutationDebounceTimer = null;

    function get_tabkey(id) {
        return "multi-highlight_" + id;
    }

    function get_tabId(key) {
        return parseInt(key.substring(16), 10);
    }

    function isBlacklisted(settings) {
        if (!settings || !Array.isArray(settings.blacklist) || settings.blacklist.length === 0) {
            return false;
        }
        const currentUrl = (window.location.host || "").toLowerCase();
        return settings.blacklist.some(blacklistedUrl => {
            return blacklistedUrl && currentUrl.includes(String(blacklistedUrl).toLowerCase().trim());
        });
    }

    function KeywordEscape(kw) {
        return kw.replace(/\n/sgi, "\\n");
    }

    function hl_clearall(settings) {
        if (observer) observer.disconnect();
        try {
            $(document.body).unhighlight({
                className: settings.CSSprefix1,
                element: settings.element || "mh"
            });
        } catch (e) {
            console.warn("[Multi-Highlight] Clear error:", e);
        }
        if (observer) attachObserver();
    }

    function _hl_clear(removedKws, settings) {
        if (!removedKws || removedKws.length === 0) return;
        if (observer) observer.disconnect();

        const removedKws_flatten = removedKws.flat();
        for (let i = 0; i < removedKws_flatten.length; i++) {
            const kw = removedKws_flatten[i];
            if (!kw || !kw.kwStr) continue;

            const safeClassName = (settings.CSSprefix3 + encodeURIComponent(kw.kwStr)).replace(
                /[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g,
                "\\$&"
            );
            $(document.body).unhighlight({
                className: safeClassName,
                element: settings.element || "mh"
            });
        }

        if (observer) attachObserver();
    }

    function _hl_search(addedKws, settings) {
        if (!addedKws || addedKws.length === 0) return;
        if (isBlacklisted(settings)) return;

        const isWholeWord = Boolean(settings.isWholeWord);
        const isCasesensitive = Boolean(settings.isCasesensitive);
        const clsPrefix = settings.CSSprefix1 + " " + settings.CSSprefix2;

        const sortedKws = [...addedKws].sort((a, b) => (b.kwStr || "").length - (a.kwStr || "").length);

        if (observer) observer.disconnect();

        for (let i = 0; i < sortedKws.length; i++) {
            const kw = sortedKws[i];
            if (!kw || !kw.kwStr) continue;

            const hl_param1 = KeywordEscape(kw.kwStr);
            const hlClass = clsPrefix + (kw.kwGrp % 20) + " " + settings.CSSprefix3 + encodeURIComponent(kw.kwStr);

            $(document.body).highlight(hl_param1, {
                className: hlClass,
                wordsOnly: isWholeWord,
                caseSensitive: isCasesensitive,
                element: settings.element || "mh"
            });
        }

        if (observer) attachObserver();
    }

    function hl_refresh(kws, settings) {
        hl_clearall(settings);
        if (kws && kws.length > 0) {
            _hl_search(kws, settings);
        }
    }

    const MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
    const MutationObserverConfig = {
        childList: true,
        subtree: true,
        characterData: true
    };

    function attachObserver() {
        if (!observer || !document.body) return;
        try {
            observer.observe(document.body, MutationObserverConfig);
        } catch (e) {}
    }

    // Initialize content script
    chrome.runtime.sendMessage({ action: "getTabId" }, function (response) {
        if (chrome.runtime.lastError || !response || !response.tabId) {
            return;
        }

        tabId = response.tabId;
        tabkey = get_tabkey(tabId);

        // Setup debounced MutationObserver to avoid CPU thrashing on dynamic SPAs
        if (MutationObserver && document.body) {
            observer = new MutationObserver(function () {
                clearTimeout(mutationDebounceTimer);
                mutationDebounceTimer = setTimeout(function () {
                    chrome.storage.local.get(["settings", tabkey], function (result) {
                        if (!result || !result.settings || !result[tabkey]) return;
                        const settings = result.settings;
                        const tabinfo = result[tabkey];

                        if (settings.isOn && settings.isAlwaysSearch && tabinfo.keywords && tabinfo.keywords.length > 0) {
                            hl_refresh(tabinfo.keywords, settings);
                        }
                    });
                }, 250);
            });

            attachObserver();
        }

        // Setup message listener
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (!request || !request.action) return;

            chrome.storage.local.get(["settings", tabkey], function (result) {
                if (!result || !result.settings) {
                    sendResponse({ action: "null" });
                    return;
                }
                const settings = result.settings;
                const tabinfo = result[tabkey] || { keywords: [] };

                switch (request.action) {
                    case "hl_clearall":
                        hl_clearall(settings);
                        break;
                    case "hl_refresh":
                        hl_refresh(request.inputKws || [], settings);
                        break;
                    case "hl_refresh_existing":
                        hl_refresh(tabinfo.keywords || [], settings);
                        break;
                    case "_hl_search":
                        _hl_search(request.addedKws || [], settings);
                        break;
                    case "_hl_clear":
                        _hl_clear(request.removedKws || [], settings);
                        break;
                }

                sendResponse({ action: "success" });
            });

            return true; // Keep message channel open for async response
        });
    });
})();