/**
 * Multi Highlight — Options Dashboard Logic
 * Enterprise Edition (Manifest V3)
 */
"use strict";

const defaultSettings = {
    delim: ",",
    isAlwaysSearch: false,
    isOn: true,
    isCasesensitive: false,
    isInstant: true,
    isNewlineNewColor: false,
    isSaveKws: false,
    isWholeWord: false,
    latest_keywords: [],
    element: "mh",
    CSSprefix1: "chrome-extension-FindManyStrings",
    CSSprefix2: "chrome-extension-FindManyStrings-style-",
    CSSprefix3: "CE-FMS-",
    enableAddKw: true,
    enableRemoveKw: true,
    blacklist: []
};

const defaultPopupConfig = {
    popup_height: 100,
    popup_width: 420
};

document.addEventListener("DOMContentLoaded", function () {
    const popupHeight = document.getElementById("popupHeight");
    const popupWidth = document.getElementById("popupWidth");
    const addKw = document.getElementById("addKw");
    const removeKw = document.getElementById("removeKw");
    const blacklist = document.getElementById("blacklist");
    const saveToast = document.getElementById("saveToast");
    const exportBtn = document.getElementById("exportSettingsBtn");
    const importFile = document.getElementById("importSettingsFile");
    const resetBtn = document.getElementById("resetDefaultsBtn");

    let toastTimer = null;
    function showToast(msg) {
        if (!saveToast) return;
        saveToast.textContent = msg || "Settings saved";
        saveToast.classList.add("visible");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
            saveToast.classList.remove("visible");
        }, 1800);
    }

    function safeSendMessage(msg) {
        try {
            chrome.runtime.sendMessage(msg, function () {
                const err = chrome.runtime.lastError;
            });
        } catch (e) {}
    }

    // Load initial settings
    chrome.storage.local.get(["settings", "popupConfig"], function (result) {
        const settings = Object.assign({}, defaultSettings, result.settings);
        const popupConfig = Object.assign({}, defaultPopupConfig, result.popupConfig);

        popupHeight.value = popupConfig.popup_height || 100;
        popupWidth.value = popupConfig.popup_width || 420;
        addKw.checked = Boolean(settings.enableAddKw);
        removeKw.checked = Boolean(settings.enableRemoveKw);
        blacklist.value = Array.isArray(settings.blacklist) ? settings.blacklist.join("\n") : (settings.blacklist || "");

        // Dimension Listeners
        $("#popupHeight").on("input change", function () {
            const val = parseInt($(this).val(), 10) || 100;
            chrome.storage.local.get(["popupConfig"], function (res) {
                const cfg = Object.assign({}, defaultPopupConfig, res.popupConfig);
                cfg.popup_height = Math.max(80, Math.min(500, val));
                chrome.storage.local.set({ popupConfig: cfg }, () => showToast("Height updated"));
                safeSendMessage({ action: "handle_popupSize_change", newHeight: cfg.popup_height, newWidth: null });
            });
        });

        $("#popupWidth").on("input change", function () {
            const val = parseInt($(this).val(), 10) || 420;
            chrome.storage.local.get(["popupConfig"], function (res) {
                const cfg = Object.assign({}, defaultPopupConfig, res.popupConfig);
                cfg.popup_width = Math.max(380, Math.min(760, val));
                chrome.storage.local.set({ popupConfig: cfg }, () => showToast("Width updated"));
                safeSendMessage({ action: "handle_popupSize_change", newHeight: null, newWidth: cfg.popup_width });
            });
        });

        // Context Menu Toggles
        $("#addKw").on("change", function () {
            const enabled = $(this).prop("checked");
            chrome.storage.local.get(["settings"], function (res) {
                const set = Object.assign({}, defaultSettings, res.settings);
                set.enableAddKw = enabled;
                chrome.storage.local.set({ settings: set }, () => showToast("Context menu updated"));
                safeSendMessage({ action: "handle_addKw_change", enableIt: enabled });
            });
        });

        $("#removeKw").on("change", function () {
            const enabled = $(this).prop("checked");
            chrome.storage.local.get(["settings"], function (res) {
                const set = Object.assign({}, defaultSettings, res.settings);
                set.enableRemoveKw = enabled;
                chrome.storage.local.set({ settings: set }, () => showToast("Context menu updated"));
                safeSendMessage({ action: "handle_removeKw_change", enableIt: enabled });
            });
        });

        // Blacklist Listener
        let blacklistTimer = null;
        $("#blacklist").on("input", function () {
            const text = $(this).val();
            clearTimeout(blacklistTimer);
            blacklistTimer = setTimeout(() => {
                safeSendMessage({ action: "handle_blacklist_change", newBlacklist: text });
                showToast("Blacklist saved");
            }, 300);
        });

        // Export Configuration
        if (exportBtn) {
            exportBtn.addEventListener("click", function () {
                chrome.storage.local.get(null, function (allData) {
                    const exportObj = {
                        app: "Multi Highlight Enterprise",
                        version: "2.11.1",
                        exportedAt: new Date().toISOString(),
                        settings: allData.settings || defaultSettings,
                        popupConfig: allData.popupConfig || defaultPopupConfig
                    };
                    const blob = new Blob([JSON.stringify(exportObj, null, 2)], { type: "application/json" });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `multi-highlight-config-${new Date().toISOString().slice(0, 10)}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                    showToast("Configuration exported");
                });
            });
        }

        // Import Configuration
        if (importFile) {
            importFile.addEventListener("change", function (e) {
                const file = e.target.files && e.target.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = function (evt) {
                    try {
                        const imported = JSON.parse(evt.target.result);
                        if (imported && (imported.settings || imported.popupConfig)) {
                            chrome.storage.local.set({
                                settings: Object.assign({}, defaultSettings, imported.settings),
                                popupConfig: Object.assign({}, defaultPopupConfig, imported.popupConfig)
                            }, function () {
                                showToast("Configuration imported!");
                                setTimeout(() => window.location.reload(), 600);
                            });
                        } else {
                            alert("Invalid configuration file format.");
                        }
                    } catch (err) {
                        alert("Error parsing JSON configuration file.");
                    }
                };
                reader.readAsText(file);
            });
        }

        // Reset to Defaults
        if (resetBtn) {
            resetBtn.addEventListener("click", function () {
                if (confirm("Reset all Multi Highlight settings and configurations to factory defaults?")) {
                    chrome.storage.local.set({
                        settings: defaultSettings,
                        popupConfig: defaultPopupConfig
                    }, function () {
                        showToast("Reset to defaults");
                        setTimeout(() => window.location.reload(), 500);
                    });
                }
            });
        }
    });
});
